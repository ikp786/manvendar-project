{{--  <ul class="nav nav-tabs" >
            @if(in_array(Auth::user()->role_id,array(1,4)))
             <li><a href="{{ url('show-revenue-expenses') }}"><span>Revenue</span></a></li>
		 
		         @if(Auth::user()->role_id == 1)
             <li><a href="{{url('admin/user-lists')}}"><span>Business Invoice</span></a></li>
      
             <li><a href="#"><span>Travel</span></a></li>
             @endif
             @endif
</ul>--}}