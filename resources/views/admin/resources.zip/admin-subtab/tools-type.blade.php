       
	   {{--   <ul class="nav nav-tabs" >

           <li class="{{(Request::is('admin/otp') ? 'active' : '')}}"><a href="{{route('admin/otp')}}"><span>OTP Manager</span></a></li> 
            <li class="{{(Request::is('/admin/bankupdown') ? 'active' : '')}}"><a href="{{url('/admin/bankupdown')}}"><span>Bank Management</span></a></li> 
                   
            <li class="{{(Request::is('txn-in-queue') ? 'active' : '')}}"><a href="{{url('txn-in-queue')}}"><span>Txn In Queue</span></a></li> 
             
	   </ul>--}}