<html>
<head></head>
<body style="background: black; color: white">
<h1><input type="text" value="title" name="title"></h1>
<p><input type="text" value="content" name="content"></p>
</body>
</html>