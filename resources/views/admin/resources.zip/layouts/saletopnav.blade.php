
<div class="col-md-12" style="margin-top: -54px;">
   <nav class="navbar navbar-default agent-header-color" style="margin-top: 0px;">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand agent-font-color" href="#"></a>
          </div>
          <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav"> 
            <li><a href="{{ url('dashboard') }}">Dashboard</a></li>
             <li><a href="{{ url('sales/agent-lists') }}">Member</a></li>
            <!-- <li><a href="{{ url('daily-balance-report') }}">Report</a></li> -->
			
            </ul>
            
          </div><!--/.nav-collapse -->
       
      </nav>
  </div>