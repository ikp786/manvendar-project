<footer class="footer text-right" style="botom:0">
    <div class="container">
        <div class="row">
            <div class="col-xs-12" style="text-align: center;">
             <p>© 2018 Shighra Pay is  Registered brand name of Volant Infoserve Pvt. Ltd.</p>
			 <p>Helpdesk number +91 22 2757 1003, Email : care@shighrapay.com</p>
            </div>
           
        </div>
    </div>
</footer>